public enum Branch {
    TENKASI("TEN"),
    TIRUNELVELI("TVL"),
    KALAKAD("KKD"),
    CHENNAI("CHE"),
    AMBAI("AMB");
    String branchCode;
    Branch(String BranchCode) {
        branchCode = BranchCode;
    }
}
