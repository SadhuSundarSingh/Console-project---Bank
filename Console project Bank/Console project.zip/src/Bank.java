import java.util.ArrayList;

public class Bank {
    static ArrayList<Long> aaharNumberList = new ArrayList<Long>();
    static ArrayList<Account> accountList = new ArrayList<Account>();
    static ArrayList<String> accountNumberList = new ArrayList<String>();
    static ArrayList<Admin> adminList = new ArrayList<Admin>();
    static ArrayList<String> adminIdList = new ArrayList<String>();
}